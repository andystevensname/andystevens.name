# ActivityPub for Astro on Netlify

A two-way ActivityPub implementation for a static Astro site on Netlify.
Lets people follow `@andy@andystevens.name` from Mastodon (and other fediverse
servers), receive your new blog posts, and reply/like them.

## What's in here

```
netlify/functions/
  webfinger.mjs       - Serves /.well-known/webfinger (dynamic; handles any resource= query)
  actor.mjs           - Serves /ap/actor (your profile as ActivityPub JSON)
  inbox.mjs           - Receives Follow, Undo, Like, Create (replies), Delete
  followers.mjs       - Serves /ap/followers collection
  outbox.mjs          - Serves /ap/outbox collection
  note.mjs            - Serves /ap/notes/:slug (ActivityPub JSON for a post)
  deliver.mjs         - Called manually or via build hook to deliver a new post
src/lib/
  crypto.mjs          - HTTP Signature signing + verifying
  storage.mjs         - Follower/activity storage (Netlify Blobs, swappable)
  activitypub.mjs     - Builds actor/note/activity JSON objects
scripts/
  generate-keys.mjs   - One-time: generate your RSA keypair
  publish.mjs         - Post-build hook: deliver new posts to followers
netlify.toml          - Function config + redirects for pretty URLs
public/.well-known/   - (optional) static fallback if you prefer
```

## Storage portability

We use Netlify Blobs by default because it's zero-config on Netlify. The
`storage.mjs` module is a thin wrapper with only 6 functions:

- `addFollower(actorUrl, inboxUrl, sharedInboxUrl?)`
- `removeFollower(actorUrl)`
- `listFollowers()`
- `hasFollower(actorUrl)`
- `recordActivity(id, json)` (idempotency + audit trail)
- `getActivity(id)`

To migrate off Netlify: swap this one file for a Turso / Supabase / SQLite /
filesystem implementation. Data model is simple key-value JSON.

## Setup

1. `npm install @netlify/blobs`
2. `node scripts/generate-keys.mjs` — prints a public and private key. Copy them.
3. In Netlify UI → Site settings → Environment variables, set:
   - `AP_DOMAIN` = `andystevens.name`
   - `AP_USERNAME` = `andy`
   - `AP_DISPLAY_NAME` = `Andy Stevens`
   - `AP_SUMMARY` = `Short bio.`
   - `AP_ICON_URL` = `https://andystevens.name/avatar.jpg`
   - `AP_PRIVATE_KEY` = (the private key, preserve newlines as `\n`)
   - `AP_PUBLIC_KEY` = (the public key, preserve newlines as `\n`)
4. Deploy. Test with `curl -H "Accept: application/activity+json" https://andystevens.name/.well-known/webfinger?resource=acct:andy@andystevens.name`
5. Search `@andy@andystevens.name` from any Mastodon instance.

## Publishing a new post

In your Astro build, emit a JSON file per post with ActivityPub shape (see
`src/lib/activitypub.mjs` for `buildNote`). After build, either:

- Call `POST https://andystevens.name/api/deliver` with `{ "slug": "my-post" }`
  and a shared secret in the `Authorization` header, or
- Run `node scripts/publish.mjs my-post` as a post-build step.

This fetches your follower list and POSTs a signed `Create` activity to each
follower's inbox. Mastodon then shows the post in their timeline.

## Known limitations

- No media/attachments in outgoing posts yet (text and links only).
- `Announce` (boosts) inbound not handled beyond being stored.
- No pagination on outbox/followers (fine under ~100 followers).
- No queue/retry on delivery failures (add BullMQ or a scheduled function for
  production scale).
