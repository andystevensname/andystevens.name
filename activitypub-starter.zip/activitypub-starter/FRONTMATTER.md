# Frontmatter conventions for federation

Per-post opt-in. Add `federate: true` to any post's frontmatter to publish it
to Mastodon. Without it, the post stays web-only.

## All types (applies to every collection)

```yaml
---
title: "My Post"           # required except for notes
date: 2026-04-24           # required; Date or ISO string
draft: false               # optional; drafts are always skipped
federate: true             # required to federate (opt-in gate)
tags: [indieweb, fediverse] # optional; become #hashtags on Mastodon
summary: "One-line desc"   # optional; used as CW/summary on Mastodon
inReplyTo: "https://example.com/post"  # optional; makes this a reply
---
```

## articles/

Long-form blog posts. Federates as ActivityPub `Article`.
Mastodon shows these with a title and a "Read more" link.

```yaml
---
title: "Thoughts on the open web"
date: 2026-04-24
federate: true
tags: [indieweb]
---
```

## notes/

Short, titleless posts. Federates as `Note`.
These show up in Mastodon timelines in full, like a regular toot.

```yaml
---
date: 2026-04-24T15:30:00Z
federate: true
---
Just had the best coffee.
```

## poems/

Federates as `Article` (so the title is preserved).
Your remark-poem-element plugin's HTML output is included as-is.
Tip: if the rendered HTML is visually-heavy (line breaks, indentation),
test how Mastodon displays it — some custom HTML gets stripped.

## photos/

Federates as `Note` with image attachments.

```yaml
---
date: 2026-04-24
federate: true
image: /images/2026-04/beach.jpg
# Or multiple:
# image:
#   - /images/2026-04/beach.jpg
#   - /images/2026-04/beach-sunset.jpg
summary: "Sunset at Brigantine Beach"  # used as alt text + CW
---
```

For proper per-image alt text (recommended for accessibility), update the
integration's `buildAttachments` function to accept `{ src, alt }` objects
and use `alt` as the `name` field.

## code/

Federates as `Article`. Your shiki-highlighted code gets embedded as HTML.
Mastodon will strip most styling but preserve `<code>` and `<pre>` tags,
so the code remains readable even without the theme colors.

## bookmarks/

Federates as `Note` with the bookmarked URL appended.

```yaml
---
date: 2026-04-24
federate: true
url: "https://example.com/interesting-article"
summary: "Why this matters"
---
Quick thoughts about what I found interesting...
```

## likes/

Federates as a `Like` activity (not a post).
Only works if the target URL resolves to an ActivityPub object — i.e., the
thing you liked is on Mastodon, another fediverse server, or a site that
advertises ActivityPub via `<link rel="alternate" type="application/activity+json">`.

```yaml
---
date: 2026-04-24
federate: true
likeOf: "https://mastodon.social/@someone/12345"
---
```

If `likeOf` points at a regular non-fediverse URL, the delivery will return
a 422 with a friendly error. The like still gets published as a web page on
your site (via IndieWeb conventions), it just doesn't federate.

## Summary table

| Collection | AP Type   | Key extra field |
|------------|-----------|-----------------|
| articles   | Article   | —               |
| notes      | Note      | —               |
| poems      | Article   | —               |
| photos     | Note      | `image`         |
| code       | Article   | —               |
| bookmarks  | Note      | `url`           |
| likes      | Like      | `likeOf`        |

## Publishing workflow

```bash
# After writing a post with federate: true in frontmatter:
npm run build       # regenerates data/posts.json
git push            # deploys to Netlify
node scripts/publish.mjs articles my-new-post
```

The publish step is currently manual because auto-delivering on every deploy
would spam followers if you ever edit old posts. Better to explicitly choose
when to fan out.
