// scripts/copy-manifest.mjs
// Runs after `astro build`. Copies the rendered ap-manifest.json from dist/
// to data/ where the Netlify functions expect it.
//
// Add to package.json:
//   "build": "astro build && node scripts/copy-manifest.mjs"

import { copyFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';

const src = 'dist/ap-manifest.json';
const dst = 'data/posts.json';

if (!existsSync(src)) {
  console.error(`expected ${src} to exist after astro build`);
  process.exit(1);
}

await mkdir('data', { recursive: true });
await copyFile(src, dst);
console.log(`copied ${src} → ${dst}`);
