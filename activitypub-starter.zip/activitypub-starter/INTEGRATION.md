# Astro ActivityPub integration — setup notes

There are two approaches to generating the posts manifest. Try the first one;
fall back to the second if you hit issues.

## Approach 1: Integration hook (simpler)

Add to `astro.config.mjs`:

```js
import activitypub from './src/integrations/activitypub.mjs';

export default defineConfig({
  // ...
  integrations: [
    activitypub({
      collection: 'blog',
      blogUrlPath: '/blog',
      domain: process.env.AP_DOMAIN,
    }),
  ],
});
```

Run `astro build`. You should see:

```
wrote ActivityPub manifest: N posts → data/posts.json
```

**Caveat:** This reads `entry.rendered.html`, which is populated by the glob()
loader but only for markdown files. If you use MDX or custom loaders, the
HTML may be empty. If that happens, use Approach 2.

## Approach 2: Build-time endpoint (more reliable)

1. Drop `src/pages/ap-manifest.json.ts` into your project (already in this
   starter).
2. In `astro.config.mjs`, **remove** the `activitypub()` integration import.
3. Update `package.json`:

   ```json
   "scripts": {
     "build": "astro build && node scripts/copy-manifest.mjs"
   }
   ```

4. Run `astro build`. The endpoint renders as `dist/ap-manifest.json`, then
   `copy-manifest.mjs` moves it to `data/posts.json`.

This approach uses Astro's official container rendering API and is guaranteed
to produce correct HTML regardless of content loader or markdown flavor.

## After either approach

Add to `netlify.toml`:

```toml
[functions]
  node_bundler = "esbuild"
  included_files = ["data/posts.json"]
```

Without `included_files`, your functions won't see the manifest at runtime.

## Content schema

The integration expects each entry to have at least:

- `title` (string)
- `date` (Date or ISO string)
- `draft` (boolean, optional)
- `tags` (array of strings, optional)

If your frontmatter uses different field names, pass them as options to the
integration:

```js
activitypub({
  collection: 'posts',
  dateField: 'publishedAt',
  draftField: 'isDraft',
});
```

## Content negotiation on post URLs (optional, nice-to-have)

The `src/middleware.ts` file makes your real blog URLs double as ActivityPub
object URLs. This only works with `output: 'hybrid'` or `'server'` — with
static output, Astro emits static HTML with no way to branch on `Accept`.

If you're staying static, delete `src/middleware.ts` and let people find
posts via `/ap/notes/:slug` (the Netlify function).

If you go hybrid:

```js
// astro.config.mjs
export default defineConfig({
  output: 'hybrid',
  adapter: netlify(),
  // ...
});
```

Then only the blog post route needs to opt out of prerendering:

```astro
---
// src/pages/blog/[slug].astro
export const prerender = false;
---
```

Tradeoff: dynamic route = a Netlify function invocation on every page load,
which costs build minutes and adds latency. Most people stick with static +
the `/ap/notes/:slug` route.

## Testing locally

```bash
netlify dev
curl -H "Accept: application/activity+json" \
  "http://localhost:8888/.well-known/webfinger?resource=acct:andy@andystevens.name"
```

Netlify Dev runs your functions against the local filesystem, so `data/posts.json`
must exist before you start the dev server. Run `npm run build` at least once.
