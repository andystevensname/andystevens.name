// astro.config.mjs - merged with your existing config
//
// This is your uploaded config + the ActivityPub integration.
// The only new lines are the import at the top and the integrations: [] array.

import { defineConfig } from 'astro/config';
import remarkPoemElement from '@andystevensname/remark-poem-element';
import remarkDirective from 'remark-directive';
import remarkProjectMetaBar from '@andystevensname/remark-project-meta-bar';

import activitypub from './src/integrations/activitypub.mjs';

export default defineConfig({
  site: 'https://andystevens.name',
  output: 'static',
  redirects: {
    '/blog': '/articles/',
  },
  build: {
    inlineStylesheets: 'always',
  },
  markdown: {
    remarkPlugins: [remarkPoemElement, remarkDirective, remarkProjectMetaBar],
    shikiConfig: {
      themes: {
        light: 'github-light',
        dark: 'github-dark',
      },
    },
  },
  vite: {
    server: {
      allowedHosts: [
        '.ngrok-free.app',
        '.ngrok-free.dev',
        'andystevens.name',
        'localhost',
      ],
    },
  },

  integrations: [
    activitypub({
      domain: process.env.AP_DOMAIN || 'andystevens.name',
      // Per-post opt-in: add `federate: true` to any frontmatter to publish
      // to Mastodon. Without that flag, posts stay web-only.
      federateByDefault: false,
      sources: [
        { collection: 'articles', path: '/articles', type: 'Article' },
        { collection: 'notes', path: '/notes', type: 'Note' },
        { collection: 'poems', path: '/poems', type: 'Article' },
        {
          collection: 'photos',
          path: '/photos',
          type: 'Note',
          imageField: 'image',
        },
        { collection: 'code', path: '/code', type: 'Article' },
        {
          collection: 'bookmarks',
          path: '/bookmarks',
          type: 'Note',
          linkField: 'url',
        },
        {
          collection: 'likes',
          path: '/likes',
          type: 'Like',
          targetField: 'likeOf',
        },
        // Adjust the `path` values above if your site uses different URL
        // structures. The path has to match where the HTML page actually
        // lives on your site — otherwise clicking through from Mastodon
        // will 404.
      ],
    }),
  ],
});
