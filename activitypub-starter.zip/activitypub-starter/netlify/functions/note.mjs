import { buildFromManifestItem } from '../../src/lib/activitypub.mjs';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

// Note: the route should be updated to /ap/:collection/:slug now that we
// have multiple collections. See netlify.toml for the redirect.

export default async (request) => {
  const url = new URL(request.url);
  const slug = url.searchParams.get('slug');
  const collection = url.searchParams.get('collection');
  if (!slug) return new Response('missing slug', { status: 400 });

  let posts = [];
  try {
    const here = dirname(fileURLToPath(import.meta.url));
    const manifestPath = join(here, '..', '..', 'data', 'posts.json');
    posts = JSON.parse(await readFile(manifestPath, 'utf8'));
  } catch {
    return new Response('no posts', { status: 404 });
  }

  const post = posts.find(
    (p) => p.slug === slug && (!collection || p.collection === collection)
  );
  if (!post) return new Response('not found', { status: 404 });

  // Likes don't have a federated object representation
  if (post.apType === 'Like') {
    return new Response('likes are not standalone objects', { status: 404 });
  }

  const { object } = buildFromManifestItem(post);
  if (!object) return new Response('not found', { status: 404 });

  const accept = request.headers.get('accept') || '';
  if (accept.includes('text/html') && !accept.includes('activity+json')) {
    return Response.redirect(post.url, 302);
  }

  return new Response(JSON.stringify(object), {
    status: 200,
    headers: {
      'Content-Type': 'application/activity+json; charset=utf-8',
      'Cache-Control': 'public, max-age=300',
    },
  });
};
