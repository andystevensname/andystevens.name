// src/integrations/activitypub.mjs
//
// Multi-collection ActivityPub integration. Each source maps a content
// collection to an ActivityPub object type and defines how frontmatter
// translates to the federated post.
//
// Usage in astro.config.mjs:
//
//   import activitypub from './src/integrations/activitypub.mjs';
//
//   export default defineConfig({
//     integrations: [
//       activitypub({
//         domain: 'andystevens.name',
//         sources: [
//           { collection: 'articles', path: '/articles', type: 'Article' },
//           { collection: 'notes',    path: '/notes',    type: 'Note' },
//           { collection: 'poems',    path: '/poems',    type: 'Article' },
//           { collection: 'photos',   path: '/photos',   type: 'Note',
//             imageField: 'image' },
//           { collection: 'code',     path: '/code',     type: 'Article' },
//           { collection: 'bookmarks', path: '/bookmarks', type: 'Note',
//             linkField: 'url' },
//           { collection: 'likes',    path: '/likes',    type: 'Like',
//             targetField: 'likeOf' },
//         ],
//       }),
//     ],
//   });

import { writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const DEFAULT_SOURCE = {
  dateField: 'date',
  draftField: 'draft',
  federateField: 'federate',
  tagsField: 'tags',
  titleField: 'title',
  summaryField: 'summary',
  imageField: null,
  linkField: null,
  targetField: null,
};

export default function activitypub(options = {}) {
  const {
    domain = process.env.AP_DOMAIN,
    sources = [],
    outputPath = 'data/posts.json',
    federateByDefault = false,
  } = options;

  if (!sources.length) {
    throw new Error('activitypub integration: provide at least one source');
  }

  const normalizedSources = sources.map((src) => ({
    ...DEFAULT_SOURCE,
    ...src,
  }));

  return {
    name: 'activitypub-manifest',
    hooks: {
      'astro:build:done': async ({ logger }) => {
        if (!domain) {
          logger.warn(
            'AP_DOMAIN not set; skipping ActivityPub manifest generation'
          );
          return;
        }

        const { getCollection } = await import('astro:content');
        const manifest = [];
        const stats = {};

        for (const src of normalizedSources) {
          stats[src.collection] = { total: 0, federated: 0, skipped: 0 };

          let entries;
          try {
            entries = await getCollection(src.collection);
          } catch (err) {
            logger.warn(`collection "${src.collection}" not found; skipping`);
            continue;
          }

          for (const entry of entries) {
            stats[src.collection].total++;

            if (entry.data[src.draftField]) {
              stats[src.collection].skipped++;
              continue;
            }

            const federateFlag = entry.data[src.federateField];
            const shouldFederate =
              federateFlag === undefined
                ? federateByDefault
                : federateFlag === true;
            if (!shouldFederate) {
              stats[src.collection].skipped++;
              continue;
            }

            const item = buildManifestItem(entry, src, domain, logger);
            if (item) {
              manifest.push(item);
              stats[src.collection].federated++;
            } else {
              stats[src.collection].skipped++;
            }
          }
        }

        manifest.sort((a, b) => b.published.localeCompare(a.published));

        const outPath = resolve(process.cwd(), outputPath);
        await mkdir(dirname(outPath), { recursive: true });
        await writeFile(outPath, JSON.stringify(manifest, null, 2));

        const summary = Object.entries(stats)
          .map(
            ([c, s]) =>
              `${c}: ${s.federated}/${s.total} federated (${s.skipped} skipped)`
          )
          .join(', ');
        logger.info(
          `ActivityPub manifest: ${manifest.length} total → ${outputPath}`
        );
        logger.info(summary);
      },
    },
  };
}

function buildManifestItem(entry, src, domain, logger) {
  const date = entry.data[src.dateField];
  if (!date) {
    logger.warn(
      `${src.collection}/${entry.id} has no ${src.dateField}; skipping`
    );
    return null;
  }

  const slug = entry.id.replace(/\.[^.]+$/, '');
  const url = `https://${domain}${src.path}/${slug}`;
  const published =
    date instanceof Date ? date.toISOString() : new Date(date).toISOString();

  const item = {
    slug,
    collection: src.collection,
    apType: src.type,
    path: src.path,
    published,
    url,
    title: entry.data[src.titleField] || '',
    summary: entry.data[src.summaryField] || '',
    tags: entry.data[src.tagsField] || [],
    html: entry.rendered?.html ?? '',
    markdown: entry.body ?? '',
  };

  if (src.type === 'Like') {
    const target = entry.data[src.targetField];
    if (!target) {
      logger.warn(
        `${src.collection}/${entry.id} is type Like but has no ${src.targetField}`
      );
      return null;
    }
    item.likeTarget = target;
  }

  if (src.imageField) {
    const imgs = entry.data[src.imageField];
    if (imgs) {
      item.images = Array.isArray(imgs) ? imgs : [imgs];
    }
  }

  if (src.linkField) {
    item.externalLink = entry.data[src.linkField] || null;
  }

  if (entry.data.inReplyTo || entry.data['in-reply-to']) {
    item.inReplyTo = entry.data.inReplyTo || entry.data['in-reply-to'];
  }

  return item;
}
