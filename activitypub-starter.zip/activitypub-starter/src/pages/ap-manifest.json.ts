// src/pages/ap-manifest.json.ts
//
// Alternative / fallback: generate the manifest as a build-time endpoint
// instead of via the integration hook. This works more reliably than the
// integration approach because Astro's content rendering is guaranteed to
// happen when pages are built.
//
// With static output, this file gets rendered to dist/ap-manifest.json at
// build time, and you can either:
//   (a) point your functions at that path, or
//   (b) run a small post-build script that copies dist/ap-manifest.json
//       to data/posts.json where the functions expect it.
//
// Use THIS approach if the integration's `entry.rendered?.html` comes back
// empty — which can happen depending on Astro version and MDX usage.

import type { APIRoute } from 'astro';
import { getCollection, render } from 'astro:content';
import { experimental_AstroContainer as AstroContainer } from 'astro/container';

const DOMAIN = import.meta.env.AP_DOMAIN || process.env.AP_DOMAIN;
const BLOG_PATH = '/blog';

export const GET: APIRoute = async () => {
  if (!DOMAIN) {
    return new Response('AP_DOMAIN not configured', { status: 500 });
  }

  const container = await AstroContainer.create();
  const entries = await getCollection('blog', (e) => !e.data.draft);

  const manifest = [];
  for (const entry of entries) {
    const { Content } = await render(entry);
    const html = await container.renderToString(Content);
    const slug = entry.id.replace(/\.[^.]+$/, '');
    const date = entry.data.date;

    manifest.push({
      slug,
      title: entry.data.title || '',
      published:
        date instanceof Date ? date.toISOString() : new Date(date).toISOString(),
      url: `https://${DOMAIN}${BLOG_PATH}/${slug}`,
      html,
      markdown: entry.body || '',
      tags: entry.data.tags || [],
    });
  }

  manifest.sort((a, b) => b.published.localeCompare(a.published));

  return new Response(JSON.stringify(manifest, null, 2), {
    headers: { 'Content-Type': 'application/json' },
  });
};
