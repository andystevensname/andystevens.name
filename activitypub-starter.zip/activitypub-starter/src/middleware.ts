// src/middleware.ts (or .js)
//
// This makes each blog post URL self-federating: when Mastodon fetches
// https://andystevens.name/blog/my-post with Accept: application/activity+json,
// it gets the ActivityPub Note JSON instead of the HTML.
//
// This is nicer than the /ap/notes/:slug approach because the *canonical*
// URL of your post works as both a web page and an ActivityPub object.
// Mastodon's "search by URL" feature works this way.
//
// IMPORTANT: this middleware only runs on routes that go through the
// Astro server. For fully static output, you can't do content negotiation
// from the HTML page itself — you need the Netlify function route
// (/ap/notes/:slug) instead, which is what this starter already provides.
//
// If your Astro output is 'hybrid' or 'server', uncomment the middleware
// export in astro.config.mjs. If it's 'static', delete this file and rely
// on the /ap/notes/:slug function route.

import { defineMiddleware } from 'astro:middleware';
import { getEntry } from 'astro:content';

const AP_ACCEPT_TYPES = [
  'application/activity+json',
  'application/ld+json',
];

export const onRequest = defineMiddleware(async (context, next) => {
  const url = new URL(context.request.url);

  // Only intercept blog post URLs
  const blogMatch = url.pathname.match(/^\/blog\/([^/]+)\/?$/);
  if (!blogMatch) return next();

  const accept = context.request.headers.get('accept') || '';
  const wantsAP = AP_ACCEPT_TYPES.some((type) => accept.includes(type));
  if (!wantsAP) return next();

  // Serve ActivityPub JSON instead of HTML
  const slug = blogMatch[1];
  const entry = await getEntry('blog', slug);
  if (!entry) {
    return new Response('not found', { status: 404 });
  }

  const domain = import.meta.env.AP_DOMAIN || process.env.AP_DOMAIN;
  const username = import.meta.env.AP_USERNAME || process.env.AP_USERNAME;

  const note = {
    '@context': [
      'https://www.w3.org/ns/activitystreams',
      'https://w3id.org/security/v1',
    ],
    id: `https://${domain}/blog/${slug}`,
    type: entry.data.title ? 'Article' : 'Note',
    attributedTo: `https://${domain}/ap/actor`,
    to: ['https://www.w3.org/ns/activitystreams#Public'],
    cc: [`https://${domain}/ap/followers`],
    published:
      entry.data.date instanceof Date
        ? entry.data.date.toISOString()
        : new Date(entry.data.date).toISOString(),
    url: `https://${domain}/blog/${slug}`,
    name: entry.data.title,
    content: entry.rendered?.html || '',
    mediaType: 'text/html',
    tag: (entry.data.tags || []).map((t) => ({
      type: 'Hashtag',
      name: `#${t}`,
      href: `https://${domain}/tags/${t}`,
    })),
  };

  return new Response(JSON.stringify(note), {
    status: 200,
    headers: {
      'Content-Type': 'application/activity+json; charset=utf-8',
      'Cache-Control': 'public, max-age=300',
      Vary: 'Accept',
    },
  });
});
