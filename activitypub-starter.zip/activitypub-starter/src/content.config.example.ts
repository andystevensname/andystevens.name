// src/content/config.ts - EXAMPLE
//
// If you don't already have a content config, this is the minimum the
// integration expects. If you DO have one, just make sure these fields
// exist (or rename them in the integration options).

import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

const blog = defineCollection({
  loader: glob({ pattern: '**/*.{md,mdx}', base: './src/content/blog' }),
  schema: z.object({
    title: z.string(),
    date: z.coerce.date(),
    draft: z.boolean().default(false),
    tags: z.array(z.string()).default([]),
    // any other fields you already have...
  }),
});

export const collections = { blog };
